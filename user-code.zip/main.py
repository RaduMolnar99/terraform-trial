

def hello_pubsub(event, context):
    print('Hello world from linnify!')